import pandas as pd 

def data_engineer(df):
    
    return df