def eco():
    print("testando2")